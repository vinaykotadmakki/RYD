import PyPDF2
def main():
    pdfFileObj = open('D://intern/The_Living_World.pdf', 'rb')
    pdfReader = PyPDF2.PdfFileReader(pdfFileObj)  
    for i in range(pdfReader.getNumPages()):
        page = pdfReader.getPage(i)
        print("Page No :" +str(1 +pdfReader.getPageNumber(page)))
        pageContent = page.extractText()
        print(pageContent)

if __name__ == "__main__":
    main()

